from pyspark.sql.functions import *
from config import source_path, bronze_path, silver_path, base_path


def read_source(spark):
    raw_df = spark.read.csv(source_path, header=True, inferSchema=True)
    return raw_df


def build_bronze(spark, raw_df):
    bronze_df = raw_df.withColumn("ingestion_timestamp", current_timestamp())
    bronze_df = bronze_df.toDF(*[c.replace(" ", "_") for c in bronze_df.columns])
    bronze_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(bronze_path)
    bronze_df = spark.read.format("delta").load(bronze_path)
    return bronze_df


def build_silver(spark, bronze_df):

    # Remove quotes from IDs
    silver_df = (
        bronze_df
        .withColumn(
            "Booking_ID",
            regexp_replace(col("Booking_ID"), '"', "")
        )
        .withColumn(
            "Customer_ID",
            regexp_replace(col("Customer_ID"), '"', "")
        )
    )

    # Remove duplicate records
    silver_df = silver_df.dropDuplicates()

    # Data quality check
    silver_df.select([
        sum(
            when(
                col(c).isNull()
                | (trim(col(c)) == "")
                | (lower(trim(col(c))) == "null"),
                1
            ).otherwise(0)
        ).alias(c)
        for c in silver_df.columns
    ]).show(truncate=False)

    # ==========================
    # Avg_VTAT and Avg_CTAT
    # ==========================

    silver_df = (
        silver_df
        .withColumn(
            "Avg_VTAT",
            when(col("Avg_VTAT") == "null", None).otherwise(col("Avg_VTAT"))
        )
        .withColumn(
            "Avg_CTAT",
            when(col("Avg_CTAT") == "null", None).otherwise(col("Avg_CTAT"))
        )
    )

    silver_df = silver_df.withColumn(
        "Avg_VTAT",
        col("Avg_VTAT").cast("double")
    )

    silver_df = silver_df.withColumn(
        "Avg_CTAT",
        col("Avg_CTAT").cast("double")
    )

    avg_vtat = silver_df.agg(avg("Avg_VTAT")).collect()[0][0]
    avg_ctat = silver_df.agg(avg("Avg_CTAT")).collect()[0][0]

    silver_df = silver_df.fillna({
        "Avg_VTAT": avg_vtat,
        "Avg_CTAT": avg_ctat
    })

    # ==========================
    # Customer Cancellation
    # ==========================

    silver_df = silver_df.withColumn(
        "Cancelled_Rides_by_Customer",
        when(
            (col("Cancelled_Rides_by_Customer") == "null")
            | col("Cancelled_Rides_by_Customer").isNull(),
            0
        )
        .otherwise(col("Cancelled_Rides_by_Customer"))
        .cast("int")
    )

    silver_df = silver_df.withColumn(
        "Reason_for_cancelling_by_Customer",
        when(
            (col("Reason_for_cancelling_by_Customer") == "null")
            | col("Reason_for_cancelling_by_Customer").isNull(),
            "None Cancelled"
        )
        .otherwise(col("Reason_for_cancelling_by_Customer"))
    )

    # ==========================
    # Driver Cancellation
    # ==========================

    silver_df = silver_df.withColumn(
        "Cancelled_Rides_by_Driver",
        when(
            (col("Cancelled_Rides_by_Driver") == "null")
            | col("Cancelled_Rides_by_Driver").isNull(),
            0
        )
        .otherwise(col("Cancelled_Rides_by_Driver"))
        .cast("int")
    )

    silver_df = silver_df.withColumn(
        "Driver_Cancellation_Reason",
        when(
            (col("Driver_Cancellation_Reason") == "null")
            | col("Driver_Cancellation_Reason").isNull(),
            "None Cancelled"
        )
        .otherwise(col("Driver_Cancellation_Reason"))
    )

    # ==========================
    # Incomplete Rides
    # ==========================

    silver_df = silver_df.withColumn(
        "Incomplete_Rides",
        when(
            (col("Incomplete_Rides") == "null")
            | col("Incomplete_Rides").isNull(),
            0
        )
        .otherwise(col("Incomplete_Rides"))
        .cast("int")
    )

    silver_df = silver_df.withColumn(
        "Incomplete_Rides_Reason",
        when(
            (col("Incomplete_Rides_Reason") == "null")
            | col("Incomplete_Rides_Reason").isNull(),
            "None Incompleted"
        )
        .otherwise(col("Incomplete_Rides_Reason"))
    )

    # ==========================
    # Numerical Columns
    # ==========================

    numeric_cols = [
        "Booking_Value",
        "Ride_Distance",
        "Driver_Ratings",
        "Customer_Rating"
    ]

    for c in numeric_cols:

        silver_df = silver_df.withColumn(
            c,
            when(
                (col(c) == "null") | col(c).isNull(),
                None
            )
            .otherwise(col(c))
            .cast("double")
        )

        mean_value = silver_df.select(avg(c)).first()[0]

        silver_df = silver_df.fillna({
            c: mean_value
        })

    # ==========================
    # Payment Method
    # ==========================

    mode_payment = (
        silver_df
        .filter(
            (col("Payment_Method") != "null")
            & (col("Payment_Method").isNotNull())
        )
        .groupBy("Payment_Method")
        .count()
        .orderBy(col("count").desc())
        .first()[0]
    )

    silver_df = silver_df.withColumn(
        "Payment_Method",
        when(
            (col("Payment_Method") == "null")
            | col("Payment_Method").isNull(),
            mode_payment
        )
        .otherwise(col("Payment_Method"))
    )

    print(f"Most frequent Payment_Method: {mode_payment}")

    # Write Silver Layer
    silver_df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(silver_path)

    silver_df = spark.read.format("delta").load(silver_path)

    return silver_df

def build_gold(spark, silver_df):

    daily_metrics = [
    count("*").alias("total_bookings"),
    sum("Booking_Value").alias("total_revenue"),
    avg("Booking_Value").alias("average_booking_value"),
    avg("Ride_Distance").alias("average_ride_distance"),
    sum("Cancelled_Rides_by_Customer").alias("customer_cancellations"),
    sum("Cancelled_Rides_by_Driver").alias("driver_cancellations"),
    sum("Incomplete_Rides").alias("incomplete_rides"),
    avg("Driver_Ratings").alias("average_driver_rating"),
    avg("Customer_Rating").alias("average_customer_rating")
    ]

    daily_summary_df = silver_df.groupBy("Date").agg(*daily_metrics)
    daily_summary_df.show()

    gold_daily_path = f"{base_path}/gold/daily_trip_summary"
    daily_summary_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(gold_daily_path)

    daily_revenue_df = silver_df.groupBy("Date").agg(
    count("Booking_ID").alias("total_bookings"),
    round(sum("Booking_Value"), 2).alias("total_revenue"),
    round(avg("Booking_Value"), 2).alias("avg_booking_value"),
    round(max("Booking_Value"), 2).alias("highest_booking_value"),
    round(min("Booking_Value"), 2).alias("lowest_booking_value"),
    round(sum("Ride_Distance"), 2).alias("total_distance"),
    round(sum("Booking_Value") / count("Booking_ID"), 2).alias("revenue_per_booking")
    )

    daily_revenue_df.show(truncate=False)
    gold_revenue_path = f"{base_path}/gold/daily_revenue_summary"
    daily_revenue_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(gold_revenue_path)

    daily_cancellation_df = silver_df.groupBy("Date").agg(
    count("Booking_ID").alias("total_bookings"),
    sum("Cancelled_Rides_by_Customer").alias("customer_cancellations"),
    sum("Cancelled_Rides_by_Driver").alias("driver_cancellations"),
    sum("Incomplete_Rides").alias("incomplete_rides")
    )
    daily_cancellation_df.show(truncate=False)
    gold_cancellation_path = f"{base_path}/gold/daily_cancellation_summary"
    daily_cancellation_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(gold_cancellation_path)

    vehicle_performance_df = silver_df.groupBy("Vehicle_Type").agg(
    count("Booking_ID").alias("total_bookings"),
    round(sum("Booking_Value"), 2).alias("total_revenue"),
    round(avg("Booking_Value"), 2).alias("avg_booking_value"),
    round(avg("Ride_Distance"), 2).alias("avg_ride_distance"),
    round(avg("Driver_Ratings"), 2).alias("avg_driver_rating"),
    round(avg("Customer_Rating"), 2).alias("avg_customer_rating"),
    sum("Cancelled_Rides_by_Customer").alias("customer_cancellations"),
    sum("Cancelled_Rides_by_Driver").alias("driver_cancellations"),
    sum("Incomplete_Rides").alias("incomplete_rides")
    )

    vehicle_performance_df.show(truncate=False)
    gold_vehicle_performance_path = f"{base_path}/gold/vehicle_perfromance_summary"
    vehicle_performance_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(gold_vehicle_performance_path)

    return {
        "daily_summary": daily_summary_df,
        "daily_revenue": daily_revenue_df,
        "daily_cancellation": daily_cancellation_df,
        "vehicle_performance": vehicle_performance_df
    }

def run_etl(spark):
    raw_df = read_source(spark)
    bronze_df = build_bronze(spark, raw_df)
    silver_df = build_silver(spark, bronze_df)
    gold_dfs = build_gold(spark, silver_df)
    return {
        "status": "success",
        "bronze_rows": bronze_df.count(),
        "silver_rows": silver_df.count(),
        "daily_summary_rows": gold_dfs["daily_summary"].count(),
        "daily_revenue_rows": gold_dfs["daily_revenue"].count(),
        "daily_cancellation_rows": gold_dfs["daily_cancellation"].count(),
        "vehicle_performance_rows": gold_dfs["vehicle_performance"].count()
    }
















