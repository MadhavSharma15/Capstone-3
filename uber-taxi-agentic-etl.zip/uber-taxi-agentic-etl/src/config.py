#storage_account_name = "write-your-storage-account"
#container_name = "container-name"
# Paste your newly rotated storage key here.
#storage_account_key = "storage-account-key"

# Paste your Microsoft Foundry API key here.
foundry_api_key = "37YlWKevMg0q5AXVz64o33YQqJuOabzTquW3NkiuVRpjcZE5E8YPJQQJ99CJACYeBjFXJ3w3AAAAACOGKWce"
foundry_endpoint = "https://azuregemini-foundary-01.services.ai.azure.com/openai/v1"
foundry_model = "gpt-5-mini"

#storage_base = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net"

# for serverless
storage_base = "file:/Workspace/uber-taxi-agentic-etl/data"

source_path = f"{storage_base}/ncr_ride_bookings.csv"
base_path = "/Volumes/Databrick01/default/ml-data/uber-taxi-agentic-etl/output"
bronze_path = f"{base_path}/bronze"
silver_path = f"{base_path}/silver"

gold_daily_path = f"{base_path}/gold/daily_trip_summary"
gold_revenue_path = f"{base_path}/gold/daily_revenue_summary"
gold_cancellation_path = f"{base_path}/gold/daily_cancellation_summary"
gold_vehicle_performance_path = f"{base_path}/gold/vehicle_perfromance_summary"

