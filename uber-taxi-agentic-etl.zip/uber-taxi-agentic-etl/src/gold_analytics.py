from pyspark.sql.functions import *
from config import (
    gold_daily_path,
    gold_revenue_path,
    gold_cancellation_path,
    gold_vehicle_performance_path
)

def get_gold_metrics(spark):

    daily_df = spark.read.format("delta").load(gold_daily_path)

    revenue_df = spark.read.format("delta").load(gold_revenue_path)

    cancellation_df = spark.read.format("delta").load(gold_cancellation_path)

    vehicle_df = spark.read.format("delta").load(gold_vehicle_performance_path)

    # Overall KPIs
    overall = daily_df.agg(
        sum("total_bookings").alias("total_bookings"),
        sum("total_revenue").alias("total_revenue"),
        avg("average_booking_value").alias("avg_booking_value"),
        avg("average_ride_distance").alias("avg_ride_distance")
    ).first().asDict()

    # Top 10 Revenue Days
    top_revenue_days = [
        row.asDict()
        for row in revenue_df
        .orderBy(desc("total_revenue"))
        .limit(10)
        .collect()
    ]

    # Vehicle Performance
    vehicle_performance = [
        row.asDict()
        for row in vehicle_df
        .orderBy(desc("total_revenue"))
        .collect()
    ]

    # Cancellation Summary
    cancellation_summary = [
        row.asDict()
        for row in cancellation_df
        .orderBy(desc("customer_cancellations"))
        .collect()
    ]

    return {
        "overall_kpis": overall,
        "top_revenue_days": top_revenue_days,
        "vehicle_performance": vehicle_performance,
        "cancellation_summary": cancellation_summary
     }
