from pyspark.sql.functions import *
from config import silver_path

def run_quality_checks(spark):

    df = spark.read.format("delta").load(silver_path)

    # Total rows
    row_count = df.count()

    # Critical columns
    required_columns = [
        "Booking_ID",
        "Customer_ID",
        "Date",
        "Vehicle_Type",
        "Payment_Method"
    ]

    # Null count check
    null_counts = df.select([
        count(
            when(
                col(c).isNull() |
                (trim(col(c)) == ""),
                1
            )
        ).alias(c)
        for c in required_columns
    ]).first().asDict()

    # Data quality validations

    invalid_booking_value = df.filter(
        col("Booking_Value").isNull() |
        (col("Booking_Value") <= 0)
    ).count()

    invalid_ride_distance = df.filter(
        col("Ride_Distance").isNull() |
        (col("Ride_Distance") <= 0)
    ).count()

    invalid_driver_rating = df.filter(
        (col("Driver_Ratings") < 0) |
        (col("Driver_Ratings") > 5)
    ).count()

    invalid_customer_rating = df.filter(
        (col("Customer_Rating") < 0) |
        (col("Customer_Rating") > 5)
    ).count()

    duplicate_booking_ids = (
        df.groupBy("Booking_ID")
        .count()
        .filter(col("count") > 1)
        .count()
    )

    passed = (
        row_count > 0
        and all(v == 0 for v in null_counts.values())
        and invalid_booking_value == 0
        and invalid_ride_distance == 0
        and invalid_driver_rating == 0
        and invalid_customer_rating == 0
        and duplicate_booking_ids == 0
    )

    return {
        "status": "passed" if passed else "failed",
        "row_count": row_count,
        "null_counts": null_counts,
        "invalid_booking_value": invalid_booking_value,
        "invalid_ride_distance": invalid_ride_distance,
        "invalid_driver_rating": invalid_driver_rating,
        "invalid_customer_rating": invalid_customer_rating,
        "duplicate_booking_ids": duplicate_booking_ids
    }